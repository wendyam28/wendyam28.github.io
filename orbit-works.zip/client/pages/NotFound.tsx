import { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <section className="relative overflow-hidden px-4 py-24 sm:py-32">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(255,140,80,0.12),_transparent_70%)]" />
      <div className="relative mx-auto max-w-2xl rounded-[32px] border border-border/70 bg-background/90 p-10 text-center shadow-[0_24px_50px_rgba(15,23,42,0.12)]">
        <span className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-accent/30 px-4 py-1 text-xs font-semibold uppercase tracking-[0.28em] text-accent-foreground">
          404 · Route Missing
        </span>
        <h1 className="mt-8 font-display text-4xl font-semibold text-foreground">
          The warmth you’re looking for isn’t on this route yet.
        </h1>
        <p className="mt-4 text-sm text-muted-foreground">
          We couldn’t locate <span className="font-semibold">{location.pathname}</span>. Let us guide you back to the latest KindHeat mission updates or connect you with our team for support.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-4">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-[0_18px_40px_rgba(255,128,64,0.24)] transition-transform hover:-translate-y-0.5 hover:bg-primary/90"
          >
            Return Home
          </Link>
          <a
            href="mailto:hello@kindheat.org?subject=404%20support"
            className="inline-flex items-center justify-center rounded-full border border-border/70 bg-background px-6 py-3 text-sm font-semibold text-foreground transition hover:border-primary/60 hover:text-primary"
          >
            Contact KindHeat
          </a>
        </div>
      </div>
    </section>
  );
};

export default NotFound;
