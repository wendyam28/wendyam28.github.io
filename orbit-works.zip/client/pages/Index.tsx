import type { FormEvent, ReactNode } from "react";

import {
  ArrowRight,
  BatteryCharging,
  BookOpen,
  Camera,
  Check,
  Droplet,
  Feather,
  HeartHandshake,
  LineChart,
  Mail,
  MapPin,
  MessageCircle,
  Package,
  Phone,
  ShieldCheck,
  Sparkles,
  Thermometer,
  Users,
  Zap,
} from "lucide-react";

const product = {
  name: "KindHeat™ Heater Kit with Battery Pack",
  category: "Humanitarian Tech / Portable Heating",
  price: "$49.99",
  sku: "KH-BPK-001",
  shortDescription:
    "A safe, portable heater kit with battery pack designed for shelters, outreach vans, and emergency use. Compact, reusable, and built to deliver warmth and dignity anywhere it’s needed.",
  longDescription:
    "The KindHeat™ Heater Kit with Battery Pack is a lightweight, portable heating solution created for people facing cold emergencies. Designed with mobility and safety in mind, each kit provides reliable warmth powered by a rechargeable battery pack — making it ideal for shelters, cars, outreach teams, and individuals in need.",
  orderHref: "mailto:orders@kindheat.org?subject=Order%20KindHeat%20Heater%20Kit",
  sponsorHref: "https://www.gofundme.com/f/kindheat-pilot",
  contents: [
    {
      title: "Rechargeable battery pack",
      description:
        "Compact, safe, and reusable power source with charge indicators and haptic alerts for low levels.",
      icon: <BatteryCharging className="h-6 w-6" />,
      specs: ["USB-C fast recharge", "12-hour regulated warmth", "Auto shut-off protocols"],
    },
    {
      title: "Heater unit",
      description:
        "Radiant mesh heater delivers consistent, quiet warmth for bunks, cots, van benches, or personal wraps.",
      icon: <Zap className="h-6 w-6" />,
      specs: ["Even heat distribution", "Fume-free operation", "Thermal overload protection"],
    },
    {
      title: "Thermal pouch",
      description:
        "Insulated sling retains heat for extended comfort and doubles as a discreet carrying case during outreach.",
      icon: <Thermometer className="h-6 w-6" />,
      specs: ["Weatherproof shell", "Reflective lining", "Glove-friendly pulls"],
    },
    {
      title: "Emergency blanket",
      description:
        "Durable, insulating blanket that folds compactly while amplifying warmth from the heater system.",
      icon: <Feather className="h-6 w-6" />,
      specs: ["Tear-resistant weave", "Reusable design", "High-visibility trim"],
    },
    {
      title: "Quick-start guide",
      description:
        "Illustrated, language-inclusive instructions that simplify safe setup in high-stress environments.",
      icon: <BookOpen className="h-6 w-6" />,
      specs: ["Trauma-informed design", "No-text icons", "Safety checkpoints"],
    },
  ],
  features: [
    "Portable and discreet — fits easily in a backpack or glovebox",
    "Rechargeable battery pack for flexible, off-grid use",
    "Reusable components for sustainable impact",
    "Designed for humanitarian outreach and personal emergency kits",
    "Every purchase helps fund additional kits for shelters and outreach programs",
  ],
};

const heroStats = [
  { value: "72 kits", label: "pledged toward 100-kit goal" },
  { value: "23 partners", label: "shelters & outreach crews onboard" },
  { value: "1.8 hrs", label: "average kit recharge turnaround" },
  { value: "0 emissions", label: "fumes released during deployment" },
];

const techPhases = [
  {
    number: "01",
    title: "Charge anywhere",
    description:
      "Solar mats, grid outlets, or van inverters power the Aurora battery core with rapid-safe charging intelligence.",
    detail: "A 45-minute boost delivers 12 hours of regulated warmth.",
  },
  {
    number: "02",
    title: "Connect & seal",
    description:
      "Color-coded ports snap the battery into the thermal pouch and reusable heating pad. No tools, no exposed wiring.",
    detail: "All components are waterproof and safety-tested for field use.",
  },
  {
    number: "03",
    title: "Deliver dignity",
    description:
      "Volunteers distribute soft-touch kits with trauma-informed instructions, logging deployments in the KindHeat ledger.",
    detail: "Usage data keeps donors aligned with real-time impact.",
  },
];

const impactMetrics = [
  {
    value: "4,860",
    label: "nights of warmth distributed last season",
  },
  {
    value: "96%",
    label: "of recipients reported safer sleep quality",
  },
  {
    value: "38%",
    label: "reduction in diesel heater dependence",
  },
];

const testimonials = [
  {
    quote:
      "KindHeat kits mean our guests can finally sleep without shivering awake. They protect dignity as much as they protect life.",
    name: "Raymond Cho",
    role: "Director, Transit Outreach Collaborative",
  },
  {
    quote:
      "We deploy capsules during winter storms while the grid rebuilds. Battery-powered warmth buys responders critical hours.",
    name: "Leah Martinez",
    role: "Medical Lead, Harborlight Shelters",
  },
];

const fieldStories = [
  {
    title: "Portland · Night Relief Network",
    summary:
      "Teams paired KindHeat pads with onsite case managers, unlocking a 41% increase in successful housing placements.",
    detail:
      "Outreach vans carried five kits each, logging temps and battery status through the KindHeat dashboard to prioritize refills.",
  },
  {
    title: "Minneapolis · Street Med Alliance",
    summary:
      "During a record cold snap, the first 24 kits supported 280 individuals across park encampments and transit shelters.",
    detail:
      "Volunteer medics highlighted the quiet operation and trauma-informed lighting as game changers for emergency overnights.",
  },
];

const supportChannels = [
  {
    icon: <Mail className="h-5 w-5" />,
    label: "Email",
    value: "hello@kindheat.org",
    href: "mailto:hello@kindheat.org",
  },
  {
    icon: <Phone className="h-5 w-5" />,
    label: "Phone",
    value: "+1 (503) 555-1234",
    href: "tel:+15035551234",
  },
  {
    icon: <MapPin className="h-5 w-5" />,
    label: "HQ",
    value: "4218 Beacon Yard, Portland, OR",
  },
];

const fundedKits = 72;
const kitGoal = 100;
const fundingProgress = Math.min(100, Math.round((fundedKits / kitGoal) * 100));

const Index = () => {
  return (
    <div className="bg-background text-foreground">
      <HeroSection />
      <ProductSection />
      <TechnologySection />
      <KitContentsSection />
      <ImpactSection />
      <StoriesSection />
      <CampaignSection />
      <ContactSection />
    </div>
  );
};

const HeroSection = () => {
  return (
    <section id="home" className="relative overflow-hidden pt-20 sm:pt-24">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(255,143,71,0.28),_transparent_55%)]" />
      <div className="relative mx-auto max-w-7xl px-4 pb-24 lg:px-8">
        <div className="grid items-center gap-16 lg:grid-cols-[1.05fr_0.95fr]">
          <div>
            <FeatureBadge icon={<Sparkles className="h-4 w-4" />}>Powered by community & innovation</FeatureBadge>
            <h1 className="mt-6 max-w-2xl font-display text-4xl font-semibold leading-tight text-foreground sm:text-5xl lg:text-[56px]">
              Battery-powered heater kits delivering dignity-first warmth before winter hits.
            </h1>
            <p className="mt-6 max-w-xl text-lg text-muted-foreground">{product.shortDescription}</p>
            <div className="mt-8 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-2 rounded-full border border-border/70 bg-background/80 px-4 py-2 font-semibold uppercase tracking-[0.24em] text-primary">
                {product.category}
              </span>
              <span className="flex items-center gap-2 rounded-full border border-border/60 bg-card/90 px-4 py-2 font-semibold text-foreground">
                Price: <span className="font-display text-xl">{product.price}</span>
              </span>
              <span className="flex items-center gap-2 rounded-full bg-secondary px-4 py-2 font-semibold text-secondary-foreground">
                SKU {product.sku}
              </span>
            </div>
            <div className="mt-10 flex flex-wrap gap-4">
              <a
                href={product.orderHref}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-base font-semibold text-primary-foreground shadow-[0_18px_40px_rgba(255,128,64,0.32)] transition-transform hover:-translate-y-0.5 hover:bg-primary/90"
              >
                Order the kit
                <ArrowRight className="h-4 w-4" />
              </a>
              <a
                href="https://www.gofundme.com/f/kindheat-pilot"
                className="inline-flex items-center gap-2 rounded-full border border-border/70 bg-background px-6 py-3 text-base font-semibold text-foreground transition hover:border-primary/60 hover:text-primary"
              >
                Sponsor a kit
              </a>
            </div>

            <div className="mt-12 w-full max-w-xl rounded-[28px] border border-primary/30 bg-primary/10 p-6 shadow-[0_20px_45px_rgba(255,140,80,0.22)]">
              <div className="flex items-center justify-between text-sm font-semibold uppercase tracking-[0.24em] text-primary">
                <span>Launch progress</span>
                <span>
                  {fundedKits} / {kitGoal} kits funded
                </span>
              </div>
              <div className="mt-4 h-3 rounded-full bg-primary/20">
                <div
                  className="h-full rounded-full bg-primary"
                  style={{ width: `${fundingProgress}%` }}
                  role="progressbar"
                  aria-valuenow={fundingProgress}
                  aria-valuemin={0}
                  aria-valuemax={100}
                />
              </div>
              <p className="mt-4 text-xs text-muted-foreground">
                Your donation fuels hardware production, volunteer training, and battery recharges for emergency deployments.
              </p>
            </div>
          </div>

          <div className="relative space-y-6">
            <figure className="relative overflow-hidden rounded-[40px] border border-border/70 bg-background shadow-[0_30px_60px_rgba(13,18,27,0.18)]">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/12 via-transparent to-secondary/35" />
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2F577e0032890e42de89d602a2dfe88051%2F4fd85685af24458eb001c9b984293dae?format=webp&width=800"
                alt="KindHeat mobile heater kit rendered in teal and magenta"
                className="relative z-[1] w-full object-cover"
              />
              <div className="absolute left-5 top-5 z-[2] inline-flex items-center gap-2 rounded-full bg-background/90 px-4 py-2 text-xs font-semibold uppercase tracking-[0.24em] text-primary shadow-lg shadow-primary/15">
                <Sparkles className="h-4 w-4" />
                Aurora battery pack
              </div>
            </figure>
            <div className="relative overflow-hidden rounded-[40px] border border-border/70 bg-gradient-to-br from-primary/12 via-background to-secondary/40 p-8 shadow-[0_30px_60px_rgba(13,18,27,0.18)]">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/30" />
              <div className="relative flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold uppercase tracking-[0.24em] text-muted-foreground">
                    Kit at a glance
                  </p>
                  <h2 className="mt-2 font-display text-3xl font-semibold text-foreground">
                    KindHeat™ Aurora Kit
                  </h2>
                  <p className="mt-4 max-w-sm text-sm text-muted-foreground">
                    Each pack includes a rechargeable heat core, radiant thermal pad, insulated pouch, emergency blanket, and safety toolkit—designed for calm setups in high-stress moments.
                  </p>
                </div>
                <span className="flex h-16 w-16 items-center justify-center rounded-3xl bg-primary/15 text-primary">
                  <BatteryCharging className="h-8 w-8" />
                </span>
              </div>
              <ul className="mt-10 space-y-4 text-sm text-foreground/90">
                <li className="flex items-center gap-3 rounded-2xl border border-border/60 bg-background/80 px-4 py-3 shadow-inner shadow-primary/10">
                  <Zap className="h-4 w-4 text-primary" />
                  Whisper-quiet radiant heat with auto-regulation
                </li>
                <li className="flex items-center gap-3 rounded-2xl border border-border/60 bg-background/80 px-4 py-3 shadow-inner shadow-primary/10">
                  <Droplet className="h-4 w-4 text-primary" />
                  Weatherproof pouch keeps components dry in the field
                </li>
                <li className="flex items-center gap-3 rounded-2xl border border-border/60 bg-background/80 px-4 py-3 shadow-inner shadow-primary/10">
                  <Users className="h-4 w-4 text-primary" />
                  Co-designed with mutual aid teams for trauma-informed use
                </li>
              </ul>
            </div>
          </div>
        </div>

        <dl className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {heroStats.map((stat) => (
            <div
              key={stat.label}
              className="rounded-3xl border border-border/70 bg-card/85 p-5 text-left shadow-[0_12px_30px_rgba(15,23,42,0.08)]"
            >
              <dt className="text-xs font-semibold uppercase tracking-[0.24em] text-muted-foreground">
                {stat.label}
              </dt>
              <dd className="mt-3 font-display text-2xl font-semibold text-foreground">
                {stat.value}
              </dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
};

const ProductSection = () => {
  return (
    <section id="product" className="relative overflow-hidden py-20 sm:py-24">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(32,60,80,0.12),_transparent_60%)]" />
      <div className="relative mx-auto max-w-7xl px-4 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-start">
          <div className="space-y-6">
            <FeatureBadge icon={<Package className="h-4 w-4" />}>Store-ready release</FeatureBadge>
            <h2 className="font-display text-4xl font-semibold leading-tight text-foreground">
              {product.name}
            </h2>
            <p className="text-lg text-muted-foreground">{product.longDescription}</p>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl border border-border/70 bg-background/85 p-4">
                <p className="text-xs font-semibold uppercase tracking-[0.24em] text-muted-foreground">
                  Price
                </p>
                <p className="mt-2 font-display text-3xl font-semibold text-primary">{product.price}</p>
                <p className="mt-2 text-xs text-muted-foreground">
                  Order direct or sponsor a kit to send warmth to a neighbor in need.
                </p>
              </div>
              <div className="rounded-2xl border border-border/70 bg-background/85 p-4">
                <p className="text-xs font-semibold uppercase tracking-[0.24em] text-muted-foreground">
                  SKU
                </p>
                <p className="mt-2 font-display text-2xl font-semibold text-foreground">{product.sku}</p>
                <p className="mt-2 text-xs text-muted-foreground">Trackable for inventory, refills, and Builder.io product catalogs.</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-4">
              <a
                href={product.orderHref}
                className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-[0_18px_40px_rgba(255,128,64,0.28)] transition-transform hover:-translate-y-0.5 hover:bg-primary/90"
              >
                Order now
                <ArrowRight className="h-4 w-4" />
              </a>
              <a
                href={product.sponsorHref}
                className="inline-flex items-center gap-2 rounded-full border border-border/70 bg-background px-6 py-3 text-sm font-semibold text-foreground transition hover:border-primary/60 hover:text-primary"
              >
                Sponsor a kit
              </a>
            </div>
          </div>

          <div className="space-y-8">
            <figure className="relative overflow-hidden rounded-[32px] border border-border/70 bg-background shadow-[0_22px_46px_rgba(15,23,42,0.14)]">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/12 via-transparent to-secondary/25" />
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2F577e0032890e42de89d602a2dfe88051%2F1cd23eec31ea4fd8bd0c6c75cfab495c?format=webp&width=800"
                alt="KindHeat cold weather relief kit tiers infographic"
                className="relative z-[1] w-full object-cover"
              />
              <figcaption className="absolute bottom-5 left-5 z-[2] inline-flex items-center gap-2 rounded-full bg-background/90 px-4 py-2 text-xs font-semibold uppercase tracking-[0.24em] text-primary shadow-lg shadow-primary/15">
                <Package className="h-4 w-4" />
                Kit tiers overview
              </figcaption>
            </figure>
            <div className="rounded-[32px] border border-border/70 bg-card/90 p-6 shadow-[0_20px_45px_rgba(15,23,42,0.12)]">
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-muted-foreground">
                What’s inside the kit
              </p>
              <div className="mt-6 space-y-5">
                {product.contents.map((item) => (
                  <article key={item.title} className="flex gap-4">
                    <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                      {item.icon}
                    </span>
                    <div className="space-y-1">
                      <h3 className="font-display text-base font-semibold text-foreground">
                        {item.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                      <ul className="mt-2 space-y-1 text-xs text-foreground/90">
                        {item.specs.map((spec) => (
                          <li key={spec} className="flex items-center gap-2">
                            <Check className="h-3.5 w-3.5 text-primary" />
                            {spec}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </article>
                ))}
              </div>
            </div>

            <div className="rounded-[32px] border border-border/70 bg-secondary/30 p-6 shadow-[0_18px_40px_rgba(13,18,27,0.12)]">
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-muted-foreground">
                Key features
              </p>
              <ul className="mt-4 grid gap-3">
                {product.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2 text-sm text-foreground/90">
                    <Check className="mt-0.5 h-4 w-4 text-primary" />
                    {feature}
                  </li>
                ))}
              </ul>
              <p className="mt-4 text-xs text-muted-foreground">
                Bring warmth where it’s needed most. Order a kit or sponsor one today to keep communities safer through severe cold.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const TechnologySection = () => {
  return (
    <section id="technology" className="relative overflow-hidden py-20 sm:py-24">
      <div className="absolute inset-0 bg-[linear-gradient(135deg,_rgba(255,186,120,0.12),_transparent_45%),_linear-gradient(25deg,_rgba(32,60,80,0.08),_transparent_60%)]" />
      <div className="relative mx-auto max-w-7xl px-4 lg:px-8">
        <div className="flex flex-col gap-4 text-center">
          <FeatureBadge icon={<LineChart className="h-4 w-4" />}>Field-proven humanitarian tech</FeatureBadge>
          <h2 className="font-display text-4xl font-semibold text-foreground">
            Built to travel with frontline teams and perform under pressure.
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-muted-foreground">
            KindHeat™ kits are co-designed with the people who deploy them. Every component prioritizes portability, intuitive controls, and lower logistics costs compared to diesel heaters.
          </p>
        </div>

        <div className="mt-16 grid gap-6 lg:grid-cols-3">
          {techPhases.map((phase) => (
            <article
              key={phase.number}
              className="group relative overflow-hidden rounded-[32px] border border-border/70 bg-background/85 p-8 text-left shadow-[0_20px_40px_rgba(15,23,42,0.1)] transition-transform duration-300 hover:-translate-y-1"
            >
              <span className="text-sm font-semibold uppercase tracking-[0.32em] text-primary">
                {phase.number}
              </span>
              <h3 className="mt-4 font-display text-2xl font-semibold text-foreground">{phase.title}</h3>
              <p className="mt-4 text-sm text-muted-foreground">{phase.description}</p>
              <p className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.24em] text-primary">
                {phase.detail}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

const KitContentsSection = () => {
  return (
    <section id="kits" className="relative overflow-hidden py-20 sm:py-24">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(32,60,80,0.1),_transparent_60%)]" />
      <div className="relative mx-auto max-w-7xl px-4 lg:px-8">
        <div className="flex flex-col gap-4 text-center">
          <FeatureBadge icon={<Package className="h-4 w-4" />}>Kit contents</FeatureBadge>
          <h2 className="font-display text-4xl font-semibold text-foreground">
            Everything packs into a weatherproof sling, ready for emergency deployment.
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-muted-foreground">
            The KindHeat™ kit brings reliable, rechargeable warmth to shelters, outreach vans, and individuals navigating freezing nights. Components are modular so responders can service, recharge, and redeploy quickly.
          </p>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {product.contents.map((item) => (
            <article
              key={item.title}
              className="flex h-full flex-col gap-4 rounded-[28px] border border-border/70 bg-card/90 p-6 text-left shadow-[0_20px_40px_rgba(15,23,42,0.12)]"
            >
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                {item.icon}
              </span>
              <h3 className="font-display text-lg font-semibold text-foreground">{item.title}</h3>
              <p className="text-sm text-muted-foreground">{item.description}</p>
              <ul className="mt-auto space-y-1 text-xs text-foreground/90">
                {item.specs.map((spec) => (
                  <li key={spec} className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-primary" />
                    {spec}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

const ImpactSection = () => {
  return (
    <section id="impact" className="relative overflow-hidden py-20 sm:py-24">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom,_rgba(19,36,56,0.16),_transparent_58%)]" />
      <div className="relative mx-auto max-w-7xl px-4 lg:px-8">
        <div className="flex flex-col gap-4 text-center">
          <FeatureBadge icon={<HeartHandshake className="h-4 w-4" />}>Impact you can feel</FeatureBadge>
          <h2 className="font-display text-4xl font-semibold text-foreground">
            Every deployment is tracked, reported, and stewarded with community partners.
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-muted-foreground">
            Battery telemetry, field check-ins, and community-led reporting keep donors aligned with real-world outcomes. Here’s how KindHeat™ shifted last winter.
          </p>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="rounded-[36px] border border-border/70 bg-card/85 p-8 shadow-[0_24px_50px_rgba(15,23,42,0.12)]">
            <div className="grid gap-4 sm:grid-cols-3">
              {impactMetrics.map((metric) => (
                <div key={metric.label} className="rounded-2xl border border-border/60 bg-background/85 p-6 text-left shadow-inner">
                  <p className="font-display text-3xl font-semibold text-foreground">{metric.value}</p>
                  <p className="mt-3 text-xs font-semibold uppercase tracking-[0.24em] text-muted-foreground">
                    {metric.label}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-8 rounded-[28px] border border-primary/25 bg-primary/10 p-6">
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-primary">
                Telemetry snapshot
              </p>
              <p className="mt-4 text-sm text-muted-foreground">
                Outreach teams log deployments through the KindHeat mobile ledger. Battery health, hours of heat, and kit location sync automatically, ensuring the warmest response to the coldest nights.
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-6">
            {testimonials.map((testimonial) => (
              <figure
                key={testimonial.name}
                className="rounded-[32px] border border-border/70 bg-background/85 p-6 shadow-[0_22px_44px_rgba(15,23,42,0.12)]"
              >
                <MessageCircle className="h-6 w-6 text-primary" />
                <blockquote className="mt-4 text-lg text-foreground">
                  “{testimonial.quote}”
                </blockquote>
                <figcaption className="mt-4 text-sm font-semibold text-muted-foreground">
                  {testimonial.name} · {testimonial.role}
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const StoriesSection = () => {
  return (
    <section id="stories" className="relative overflow-hidden py-20 sm:py-24">
      <div className="absolute inset-0 bg-[linear-gradient(140deg,_rgba(255,186,120,0.1),_transparent_40%),_radial-gradient(circle_at_top_right,_rgba(32,60,80,0.12),_transparent_55%)]" />
      <div className="relative mx-auto max-w-7xl px-4 lg:px-8">
        <div className="flex flex-col gap-4 text-center">
          <FeatureBadge icon={<Users className="h-4 w-4" />}>Stories from the field</FeatureBadge>
          <h2 className="font-display text-4xl font-semibold text-foreground">
            Compassion moves faster when technology is ready to deploy.
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-muted-foreground">
            Hear how outreach teams and shelter staff rely on KindHeat™ kits to transform cold emergencies into safe nights of rest.
          </p>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-2">
          {fieldStories.map((story) => (
            <article
              key={story.title}
              className="flex h-full flex-col gap-4 rounded-[32px] border border-border/70 bg-card/90 p-8 text-left shadow-[0_24px_48px_rgba(15,23,42,0.12)]"
            >
              <FeatureBadge icon={<Sparkles className="h-4 w-4" />}>{story.title}</FeatureBadge>
              <h3 className="font-display text-2xl font-semibold text-foreground">{story.summary}</h3>
              <p className="text-sm text-muted-foreground">{story.detail}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

const CampaignSection = () => {
  return (
    <section id="donate" className="relative overflow-hidden py-20 sm:py-24">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(255,128,64,0.18),_transparent_60%)]" />
      <div className="relative mx-auto max-w-7xl px-4 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
          <div className="space-y-6">
            <FeatureBadge icon={<HeartHandshake className="h-4 w-4" />}>Fuel the pilot</FeatureBadge>
            <h2 className="font-display text-4xl font-semibold leading-tight text-foreground">
              Help us launch 100 KindHeat™ kits before winter.
            </h2>
            <p className="text-lg text-muted-foreground">
              Contributions power manufacturing, safety testing, partner trainings, and a shared replenishment fund that keeps cores charged all season long. Gifts are processed securely through our GoFundMe campaign.
            </p>
            <div className="rounded-[32px] border border-border/70 bg-background/85 p-6 shadow-[0_20px_45px_rgba(15,23,42,0.14)]">
              <p className="text-xs font-semibold uppercase tracking-[0.28em] text-muted-foreground">
                Why it matters
              </p>
              <ul className="mt-4 space-y-3 text-sm text-foreground/90">
                <li className="flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-primary" /> Each kit supports an individual or family through freezing nights without fumes or risk.
                </li>
                <li className="flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-primary" /> Partners log heat hours and report back so supporters see impact in real time.
                </li>
                <li className="flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-primary" /> Donations scale the manufacturing run and ensure replacement cores stay charged.
                </li>
              </ul>
            </div>
          </div>

          <div className="relative overflow-hidden rounded-[32px] border border-border/70 bg-card/95 p-4 shadow-[0_26px_52px_rgba(15,23,42,0.18)]">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-secondary/30" />
            <div className="relative rounded-[24px] border border-border/60 bg-background/95 p-4">
              <iframe
                title="KindHeat GoFundMe campaign"
                src="https://www.gofundme.com/f/kindheat-pilot/widget/large"
                className="h-[520px] w-full rounded-[18px] border-0"
                allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ContactSection = () => {
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  };

  return (
    <section id="contact" className="relative overflow-hidden pb-24 pt-20 sm:pb-32 sm:pt-24">
      <div className="absolute inset-0 bg-[linear-gradient(120deg,_rgba(32,60,80,0.12),_transparent_55%)]" />
      <div className="relative mx-auto max-w-7xl px-4 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="space-y-6">
            <FeatureBadge icon={<Mail className="h-4 w-4" />}>Partner with KindHeat™</FeatureBadge>
            <h2 className="font-display text-4xl font-semibold text-foreground">
              Let’s coordinate warmth for your community.
            </h2>
            <p className="text-lg text-muted-foreground">
              Shelters, outreach programs, municipalities, and supporters are invited to reach out. We’ll share kit specs, training schedules, and collaboration opportunities tailored to your region.
            </p>
            <div className="space-y-4">
              {supportChannels.map((channel) => {
                const content = (
                  <>
                    <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                      {channel.icon}
                    </span>
                    <span className="flex flex-col">
                      <span className="font-semibold uppercase tracking-[0.24em] text-xs text-muted-foreground">
                        {channel.label}
                      </span>
                      <span className="text-sm font-medium text-foreground/90">{channel.value}</span>
                    </span>
                  </>
                );

                if (channel.href) {
                  return (
                    <a
                      key={channel.label}
                      href={channel.href}
                      className="flex items-center gap-3 text-sm text-foreground transition hover:text-primary"
                    >
                      {content}
                    </a>
                  );
                }

                return (
                  <div
                    key={channel.label}
                    className="flex items-center gap-3 text-sm text-foreground"
                  >
                    {content}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="rounded-[36px] border border-border/70 bg-card/95 p-8 shadow-[0_24px_48px_rgba(15,23,42,0.16)]">
            <form className="grid gap-6" onSubmit={handleSubmit}>
              <div className="grid gap-2">
                <label className="text-sm font-semibold text-foreground" htmlFor="name">
                  Full name
                </label>
                <input
                  id="name"
                  name="name"
                  required
                  placeholder="Avery Johnson"
                  className="rounded-2xl border border-border/70 bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>

              <div className="grid gap-2 sm:grid-cols-2 sm:gap-4">
                <div className="grid gap-2">
                  <label className="text-sm font-semibold text-foreground" htmlFor="email">
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    placeholder="you@example.org"
                    className="rounded-2xl border border-border/70 bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                  />
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-semibold text-foreground" htmlFor="organization">
                    Organization (optional)
                  </label>
                  <input
                    id="organization"
                    name="organization"
                    placeholder="Community Outreach Collective"
                    className="rounded-2xl border border-border/70 bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                  />
                </div>
              </div>

              <div className="grid gap-2">
                <label className="text-sm font-semibold text-foreground" htmlFor="interest">
                  How can we collaborate?
                </label>
                <select
                  id="interest"
                  name="interest"
                  required
                  defaultValue=""
                  className="rounded-2xl border border-border/70 bg-background px-4 py-3 text-sm text-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                >
                  <option value="" disabled>
                    Select an option
                  </option>
                  <option value="shelter">Shelter partner</option>
                  <option value="outreach">Outreach or mutual aid crew</option>
                  <option value="sponsor">Corporate or philanthropic sponsor</option>
                  <option value="volunteer">Volunteer / training request</option>
                  <option value="press">Press inquiry</option>
                </select>
              </div>

              <div className="grid gap-2">
                <label className="text-sm font-semibold text-foreground" htmlFor="message">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  required
                  rows={4}
                  placeholder="Share how KindHeat™ can support your community."
                  className="rounded-2xl border border-border/70 bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>

              <button
                type="submit"
                className="inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-[0_18px_40px_rgba(255,128,64,0.28)] transition-transform hover:-translate-y-0.5 hover:bg-primary/90"
              >
                Send message
                <ArrowRight className="h-4 w-4" />
              </button>
              <p className="text-xs text-muted-foreground">
                We respond within two business days. Urgent cold-weather coordination requests receive priority.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

const FeatureBadge = ({ icon, children }: { icon: ReactNode; children: ReactNode }) => (
  <span className="inline-flex items-center gap-2 self-center rounded-full border border-primary/30 bg-primary/10 px-4 py-1 text-xs font-semibold uppercase tracking-[0.28em] text-primary">
    <span className="text-primary">{icon}</span>
    <span className="text-primary">{children}</span>
  </span>
);

export default Index;
