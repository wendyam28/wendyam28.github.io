import { ArrowUpRight, Flame, HeartHandshake, Mail, MapPin, Phone } from "lucide-react";

const SiteFooter = () => {
  return (
    <footer className="border-t border-border/70 bg-gradient-to-br from-background to-secondary/50 text-sm text-foreground/80">
      <div className="mx-auto max-w-7xl px-4 py-12 lg:px-8 lg:py-16">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-5">
            <div className="flex items-center gap-3 text-primary">
              <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-primary/15 shadow-inner">
                <Flame className="h-5 w-5" strokeWidth={2.4} />
              </span>
              <div className="leading-tight">
                <p className="font-display text-lg font-semibold text-foreground">
                  KindHeat™
                </p>
                <p className="text-xs uppercase tracking-[0.32em] text-primary">Warmth for everyone</p>
              </div>
            </div>
            <p className="max-w-xs text-sm text-muted-foreground">
              We design battery-powered heater kits engineered for resiliency, so shelters and outreach teams can extend life-saving warmth with dignity.
            </p>
            <div className="flex items-center gap-2 text-foreground">
              <HeartHandshake className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase tracking-[0.24em]">Impact Partners</span>
            </div>
            <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
              <span className="rounded-full bg-accent/40 px-3 py-1 font-medium text-accent-foreground/80">
                Shelter Alliance
              </span>
              <span className="rounded-full bg-accent/40 px-3 py-1 font-medium text-accent-foreground/80">
                Urban Outreach Lab
              </span>
              <span className="rounded-full bg-accent/40 px-3 py-1 font-medium text-accent-foreground/80">
                Night Relief Network
              </span>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-display text-base font-semibold text-foreground">Visit &amp; Reach</h3>
            <div className="flex items-start gap-3 text-muted-foreground">
              <MapPin className="mt-1 h-4 w-4 text-primary" />
              <p>
                4218 Beacon Yard
                <br />
                Portland, OR 97202
              </p>
            </div>
            <div className="flex items-center gap-3 text-muted-foreground">
              <Phone className="h-4 w-4 text-primary" />
              <a href="tel:+15035551234" className="hover:text-primary">
                +1 (503) 555-1234
              </a>
            </div>
            <div className="flex items-center gap-3 text-muted-foreground">
              <Mail className="h-4 w-4 text-primary" />
              <a href="mailto:hello@kindheat.org" className="hover:text-primary">
                hello@kindheat.org
              </a>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-display text-base font-semibold text-foreground">Quick Links</h3>
            <nav className="grid gap-2 text-muted-foreground">
              <a href="#product" className="flex items-center justify-between transition hover:text-primary">
                Product spotlight <ArrowUpRight className="h-4 w-4" />
              </a>
              <a href="#technology" className="flex items-center justify-between transition hover:text-primary">
                Technology <ArrowUpRight className="h-4 w-4" />
              </a>
              <a href="#kits" className="flex items-center justify-between transition hover:text-primary">
                Kit contents <ArrowUpRight className="h-4 w-4" />
              </a>
              <a href="#impact" className="flex items-center justify-between transition hover:text-primary">
                Impact <ArrowUpRight className="h-4 w-4" />
              </a>
              <a href="#donate" className="flex items-center justify-between transition hover:text-primary">
                GoFundMe campaign <ArrowUpRight className="h-4 w-4" />
              </a>
            </nav>
          </div>

          <div className="space-y-5">
            <h3 className="font-display text-base font-semibold text-foreground">Stay Warm with Updates</h3>
            <p className="text-sm text-muted-foreground">
              Quarterly stories from our teams delivering KindHeat kits and the lives changed along the way.
            </p>
            <form
              className="flex w-full flex-col gap-3 sm:flex-row"
              onSubmit={(event) => event.preventDefault()}
            >
              <input
                type="email"
                required
                placeholder="Email address"
                className="w-full rounded-full border border-border/70 bg-background px-4 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
              <button
                type="submit"
                className="inline-flex items-center justify-center rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition hover:-translate-y-0.5 hover:bg-primary/90"
              >
                Join
              </button>
            </form>
            <p className="text-xs text-muted-foreground">
              We respect your privacy. Unsubscribe anytime.
            </p>
          </div>
        </div>
      </div>
      <div className="border-t border-border/60 bg-background/60">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-6 text-xs text-muted-foreground lg:flex-row lg:items-center lg:justify-between lg:px-8">
          <p>© {new Date().getFullYear()} KindHeat. All rights reserved.</p>
          <div className="flex flex-wrap items-center gap-4">
            <a
              href="mailto:hello@kindheat.org?subject=Accessibility%20support"
              className="transition hover:text-primary"
            >
              Accessibility
            </a>
            <a
              href="mailto:hello@kindheat.org?subject=Privacy%20policy%20request"
              className="transition hover:text-primary"
            >
              Privacy Policy
            </a>
            <a href="#contact" className="transition hover:text-primary">
              Partner With Us
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default SiteFooter;
